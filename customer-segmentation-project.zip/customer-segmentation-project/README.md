# Customer Segmentation Project

An interactive Python/Streamlit dashboard using K-Means clustering to group customers by age, annual income, purchase frequency, and spending. Includes demographic and preference analysis, cluster profiles, charts, marketing recommendations, CSV upload and segmented CSV export.

## Run

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

## Input CSV schema

Required numeric columns: `Age`, `AnnualIncome`, `PurchaseFrequency`, `TotalSpend`. Optional: `CustomerID`, `Gender`, `PreferredCategory`.

The app generates **500 synthetic customer records** if no CSV is uploaded. These are not real customer records.

## How it works

1. Load CSV or synthetic sample data.
2. Clean invalid numeric rows.
3. Standardize selected clustering features with StandardScaler.
4. Train K-Means with a user-selected cluster count.
5. Show cluster sizes, spending patterns, profiles, preferred categories and a silhouette score.
6. Export customer records with segment labels.

## GitHub submission

Create a public repository named `customer-segmentation-project`, upload `app.py`, `requirements.txt`, and `README.md`, and paste the repository link in your internship portal.

## Deploy

Connect the GitHub repository to Streamlit Community Cloud and select `app.py` as the entry point.

## Limitations

K-Means assumes roughly compact clusters and is sensitive to scaling and outliers. Marketing suggestions are illustrative, not causal claims. The `Gender` and `PreferredCategory` columns are used for descriptions, not clustering, by default.
