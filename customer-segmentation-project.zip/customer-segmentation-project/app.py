import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score

st.set_page_config(page_title='Customer Segmentation', layout='wide')
st.title('Customer Segmentation Dashboard')
st.caption('K-Means clustering | Purchase behavior and demographic insights')
@st.cache_data
def sample_data():
    rng = np.random.default_rng(42)
    n = 500
    age = rng.integers(18, 70, n)
    income = np.clip(rng.normal(65000, 25000, n), 15000, 160000).round()
    frequency = np.clip(rng.poisson(9, n) + 1, 1, 35)
    spend = np.clip(income * rng.uniform(.015, .15, n) + frequency * rng.uniform(50, 400, n), 300, 30000).round()
    return pd.DataFrame({'CustomerID':[f'C{i:04d}' for i in range(1,n+1)], 'Age':age,'AnnualIncome':income,'PurchaseFrequency':frequency,'TotalSpend':spend,'Gender':rng.choice(['Female','Male','Other'],n,p=[.49,.49,.02]),'PreferredCategory':rng.choice(['Electronics','Fashion','Grocery','Home','Beauty'],n)})

uploaded = st.file_uploader('Upload customer CSV (optional)', type=['csv'])
try:
    df = pd.read_csv(uploaded) if uploaded else sample_data()
except Exception as e:
    st.error(f'Could not read CSV: {e}'); st.stop()
required=['Age','AnnualIncome','PurchaseFrequency','TotalSpend']
if any(c not in df.columns for c in required):
    st.error('CSV must include: '+', '.join(required)); st.stop()
for c in required:
    df[c]=pd.to_numeric(df[c], errors='coerce')
df=df.dropna(subset=required).copy()
if len(df)<5:
    st.error('At least 5 valid customers required.'); st.stop()
features=st.multiselect('Clustering features', required, default=required)
if not features:
    st.warning('Select at least one feature.'); st.stop()
k=st.slider('Number of customer segments',2,min(8,len(df)-1),4)
scaler=StandardScaler()
X=scaler.fit_transform(df[features])
model=KMeans(n_clusters=k,random_state=42,n_init=10)
df['Segment']=model.fit_predict(X).astype(str)
score=silhouette_score(X,model.labels_) if len(df)>k else float('nan')
a,b,c,d=st.columns(4)
a.metric('Customers',f'{len(df):,}')
b.metric('Total customer spend',f'₹{df.TotalSpend.sum():,.0f}')
c.metric('Average spend',f'₹{df.TotalSpend.mean():,.0f}')
d.metric('Silhouette score',f'{score:.2f}')
left,right=st.columns(2)
with left:
    st.plotly_chart(px.scatter(df,x='AnnualIncome',y='TotalSpend',color='Segment',hover_data=['Age','PurchaseFrequency'],title='Customer segments: income vs spending'),use_container_width=True)
with right:
    sizes=df.groupby('Segment').size().reset_index(name='Customers')
    st.plotly_chart(px.bar(sizes,x='Segment',y='Customers',color='Segment',title='Segment sizes'),use_container_width=True)
summary=df.groupby('Segment')[required].mean().round(1)
summary.insert(0,'Customers',df.groupby('Segment').size())
st.subheader('Segment profiles')
st.dataframe(summary,use_container_width=True)
if 'PreferredCategory' in df:
    pref=pd.crosstab(df['Segment'],df['PreferredCategory']).reset_index().melt(id_vars='Segment',var_name='Category',value_name='Customers')
    st.plotly_chart(px.bar(pref,x='Segment',y='Customers',color='Category',barmode='stack',title='Preferred categories by segment'),use_container_width=True)
st.subheader('Suggested marketing insights')
for seg, r in summary.iterrows():
    if r['TotalSpend']>=df.TotalSpend.quantile(.75):
        action='Offer VIP rewards and early access to premium products.'
    elif r['PurchaseFrequency']>=df.PurchaseFrequency.median():
        action='Offer loyalty points and cross-sell related products.'
    else:
        action='Try targeted promotions and personalized re-engagement campaigns.'
    st.write(f'**Segment {seg}** ({int(r["Customers"])} customers): {action}')
st.download_button('Download segmented CSV',df.to_csv(index=False).encode(),file_name='segmented_customers.csv',mime='text/csv')
st.caption('Demo data is synthetic. Segments are descriptive, not predictions or proof of marketing effectiveness.')
